import React from 'react';
import TestComp from './Testimonial';
import Title from './Title/Title';


const TestPage=()=>{
    return(
        <>
        <Title/>
        <TestComp/>
      
        </>
    )
};
 export default TestPage
import React from 'react';
import TestComp from './Testimonial';
import Footer from './footer';
import Header from './header';

const TestPage=()=>{
    return(
        <>
        <Header/>
      <TestComp/>
      <Footer/>
        </>
    )
};
 export default TestPage

import './App.css'
import TestPage from './components/TestimonialPage'





function App() {


  return (
    <>
     <TestPage/>
    
    </>
  )
}

export default App

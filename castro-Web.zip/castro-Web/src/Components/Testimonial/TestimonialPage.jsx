import React from 'react';
import TestComp from './Testimonial';

const TestPage=()=>{
    return(
        <>
      <TestComp/>
        </>
    )
};
 export default TestPage
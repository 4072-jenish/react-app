
import 'bootstrap/dist/css/bootstrap.min.css';
import  "./App.css";
import Header from "./Components/Header/Header";
import Footer from "./Components/Footer/Footer";
import Shop from "./Components/Shop";


function App() {

  return (
    <>
    {/* <Header/> */}
    <Shop/>
    {/* <Footer/> */}
    </>
  )
}

export default App

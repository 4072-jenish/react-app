
import React from 'react';
import OurService from './Components/oue-service';
import '../src/style.css'


function App() {

  return (
    <>
    <OurService/>
     </>
  )
}

export default App
